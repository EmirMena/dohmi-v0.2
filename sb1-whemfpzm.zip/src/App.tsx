import React from 'react';
import { useTranslation } from 'react-i18next';
import './i18n/index.ts';

// Layout Components
import Navbar from './components/layout/Navbar';
import Footer from './components/layout/Footer';

// Page Components
import Hero from './components/home/Hero';
import Services from './components/home/Services';
import AdvisoryForm from './components/advisory/AdvisoryForm';
import ComingSoon from './components/generic/ComingSoon';

function App() {
  const { i18n } = useTranslation();
  const [currentPage, setCurrentPage] = React.useState('home');

  React.useEffect(() => {
    const handleNavigation = (event: CustomEvent<string>) => {
      setCurrentPage(event.detail);
    };

    window.addEventListener('navigate', handleNavigation as EventListener);
    return () => {
      window.removeEventListener('navigate', handleNavigation as EventListener);
    };
  }, []);

  const renderPage = () => {
    switch (currentPage) {
      case 'advisory':
        return <AdvisoryForm />;
      case 'buy':
      case 'rent':
      case 'sell':
        return <ComingSoon />;
      default:
        return (
          <>
            <Hero />
            <Services />
          </>
        );
    }
  };

  return (
    <div
      className="min-h-screen bg-gradient-to-b from-white to-dohmi-cream"
      lang={i18n.language}
    >
      <Navbar onNavigate={setCurrentPage} currentPage={currentPage} />
      {renderPage()}
      <Footer />
    </div>
  );
}

export default App;
