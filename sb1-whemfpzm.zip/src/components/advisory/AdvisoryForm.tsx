import React from 'react';
import { Building2, User, MapPin, Phone, Home, Send } from 'lucide-react';
import ArtDecoPattern from '../reactbits/ArtDecoPattern';
import { countryCodes } from '../../data/countryCodes';
import { useAdvisoryForm } from './hooks/useAdvisoryForm';
import { FormInput } from './components/FormInput';
import { SuccessMessage } from './components/SuccessMessage';

export default function AdvisoryForm() {
  const {
    state,
    handleInputChange,
    handleStateSelect,
    handleCitySelect,
    handleCountrySelect,
    toggleCountryDropdown,
    handleSubmit,
  } = useAdvisoryForm();

  if (state.isSubmitted) {
    return <SuccessMessage userName={state.formData.name} />;
  }

  return (
    <div className="min-h-screen pt-20 relative">
      <div className="absolute inset-0 z-0">
        <ArtDecoPattern
          direction="diagonal"
          speed={0.5}
          primaryColor="rgb(255, 87, 5,0.3)"
          secondaryColor="rgb(255, 87, 5,0.3)"
          patternSize={150}
        />
      </div>
      <div className="max-w-2xl mx-auto px-4 py-16 relative z-10">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-display font-bold text-dohmi-orange mb-4">
            Asesoría Personalizada
          </h1>
          <p className="text-xl text-dohmi-copper/90">
            Déjanos tus datos y un experto te contactará para brindarte la mejor
            asesoría
          </p>
          <div className="w-24 h-1 bg-dohmi-orange mx-auto mt-6"></div>
        </div>

        <form
          onSubmit={handleSubmit}
          className="bg-white/10 backdrop-blur-md p-8 rounded-2xl border border-white/30 space-y-6"
        >
          <div className="space-y-6">
            <FormInput
              type="text"
              name="name"
              value={state.formData.name}
              onChange={handleInputChange}
              placeholder="Nombre completo"
              icon={User}
              error={state.formErrors.name}
            />

            <FormInput
              type="text"
              name="position"
              value={state.formData.position}
              onChange={handleInputChange}
              placeholder="Cargo / Área"
              icon={Building2}
              error={state.formErrors.position}
            />

            <FormInput
              type="text"
              name="company"
              value={state.formData.company}
              onChange={handleInputChange}
              placeholder="Nombre de la empresa"
              icon={Building2}
              error={state.formErrors.company}
            />

            <div className="grid grid-cols-2 gap-4">
              <div className="relative location-dropdown">
                <FormInput
                  type="text"
                  name="state"
                  value={state.formData.state}
                  onChange={handleInputChange}
                  placeholder="Estado"
                  icon={MapPin}
                  error={state.formErrors.state}
                />
                {state.showStateDropdown && state.stateOptions.length > 0 && (
                  <div className="absolute z-10 w-full mt-1 bg-dohmi-copper/80 backdrop-blur-md border border-white/30 rounded-xl max-h-48 overflow-y-auto">
                    {state.stateOptions.map((stateName, index) => (
                      <div
                        key={index}
                        className="px-4 py-2 text-white hover:bg-white/30 cursor-pointer"
                        onClick={() => handleStateSelect(stateName)}
                      >
                        {stateName}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="relative location-dropdown">
                <FormInput
                  type="text"
                  name="city"
                  value={state.formData.city}
                  onChange={handleInputChange}
                  placeholder="Ciudad"
                  icon={MapPin}
                  error={state.formErrors.city}
                  disabled={!state.formData.state}
                />
                {state.showCityDropdown && state.cityOptions.length > 0 && (
                  <div className="absolute z-10 w-full mt-1 bg-dohmi-copper/80 backdrop-blur-md border border-white/30 rounded-xl max-h-48 overflow-y-auto">
                    {state.cityOptions.map((cityName, index) => (
                      <div
                        key={index}
                        className="px-4 py-2 text-white hover:bg-white/30 cursor-pointer"
                        onClick={() => handleCitySelect(cityName)}
                      >
                        {cityName}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="flex gap-4">
              <div className="relative w-1/3 location-dropdown">
                <button
                  type="button"
                  onClick={toggleCountryDropdown}
                  className="w-full pl-12 pr-4 py-3 bg-white/10 border border-white/30 rounded-xl text-dohmi-copper focus:outline-none focus:border-dohmi-orange focus:ring-2 focus:ring-dohmi-orange/50 flex items-center justify-between"
                >
                  <Phone
                    size={20}
                    className="absolute left-4 top-1/2 transform -translate-y-1/2 text-dohmi-orange"
                  />
                  <span>
                    {countryCodes.find((c) => c.code === state.formData.country_code)?.flag}{' '}
                    {state.formData.country_code}
                  </span>
                </button>
                {state.showCountryDropdown && (
                  <div className="absolute z-10 w-full mt-1 bg-dohmi-copper/80 backdrop-blur-md border border-white/30 rounded-xl max-h-48 overflow-y-auto">
                    {countryCodes.map((country, index) => (
                      <button
                        key={index}
                        type="button"
                        onClick={() => handleCountrySelect(country.code)}
                        className="w-full px-4 py-2 text-white hover:bg-white/30 flex items-center space-x-2 text-left"
                      >
                        <span>{country.flag}</span>
                        <span>{country.code}</span>
                        <span className="text-sm text-white/70">
                          {country.country}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <div className="relative flex-1">
                <FormInput
                  type="tel"
                  name="phone"
                  value={state.formData.phone}
                  onChange={handleInputChange}
                  placeholder="Número telefónico (10 dígitos)"
                  icon={Phone}
                  error={state.formErrors.phone}
                />
              </div>
            </div>
          </div>

          <div className="flex gap-4">
            <button
              type="submit"
              className="flex-1 bg-dohmi-orange hover:bg-dohmi-yellow text-white px-6 py-4 rounded-xl transition duration-300 transform hover:scale-105 flex items-center justify-center group"
            >
              <span className="mr-2">Solicitar Asesoría</span>
              <Send
                size={20}
                className="transform transition-transform group-hover:translate-x-2"
              />
            </button>

            <button
              type="button"
              onClick={() => (window.location.href = '/')}
              className="bg-dohmi-orange hover:bg-dohmi-yellow text-white px-6 py-4 rounded-xl transition duration-300 transform hover:scale-105 flex items-center justify-center border border-white/30"
            >
              <Home size={20} />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}