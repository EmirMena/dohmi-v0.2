import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';

// Define las propiedades que acepta el componente de entrada
interface FormInputProps {
  type: string;        // Tipo de input (text, tel, etc.)
  name: string;        // Nombre del campo
  value: string;       // Valor actual del campo
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void; // Manejador de cambios
  placeholder: string; // Texto placeholder
  icon: LucideIcon;    // Icono de Lucide React
  error?: string;      // Mensaje de error (opcional)
  disabled?: boolean;  // Estado deshabilitado (opcional)
  required?: boolean;  // Campo requerido (opcional)
}

// Componente reutilizable para campos de entrada con icono y manejo de errores
export const FormInput: React.FC<FormInputProps> = ({
  type,
  name,
  value,
  onChange,
  placeholder,
  icon: Icon,
  error,
  disabled = false,
  required = true,
}) => {
  return (
    <div className="relative">
      {/* Icono del campo */}
      <Icon
        className="absolute left-4 top-1/2 transform -translate-y-1/2 text-dohmi-orange"
        size={20}
      />
      
      {/* Campo de entrada */}
      <input
        type={type}
        name={name}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        required={required}
        disabled={disabled}
        autoComplete="off"
        className={`w-full pl-12 pr-4 py-3 bg-white/10 border ${
          // Cambia el color del borde si hay error
          error ? 'border-red-500' : 'border-white/30'
        } rounded-xl text-dohmi-copper placeholder-dohmi-copper/70 focus:outline-none focus:border-dohmi-orange focus:ring-2 focus:ring-dohmi-orange/50 ${
          // Aplica estilos cuando está deshabilitado
          disabled ? 'opacity-50 cursor-not-allowed' : ''
        }`}
      />
      
      {/* Mensaje de error */}
      {error && <p className="mt-1 text-red-500 text-sm">{error}</p>}
    </div>
  );
};