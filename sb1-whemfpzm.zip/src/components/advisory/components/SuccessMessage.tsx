import React from 'react';
import { Send, Home } from 'lucide-react';
import ArtDecoPattern from '../../reactbits/ArtDecoPattern';

// Define las propiedades que acepta el componente
interface SuccessMessageProps {
  userName: string; // Nombre del usuario para personalizar el mensaje
}

// Componente que muestra el mensaje de éxito después de enviar el formulario
export const SuccessMessage: React.FC<SuccessMessageProps> = ({ userName }) => {
  return (
    <div className="min-h-screen pt-20 relative">
      {/* Fondo decorativo con patrón Art Deco */}
      <div className="absolute inset-0 z-0">
        <ArtDecoPattern
          direction="diagonal"
          speed={0.5}
          primaryColor="rgb(255, 87, 5,0.3)"
          secondaryColor="rgb(255, 87, 5,0.3)"
          patternSize={150}
        />
      </div>
      
      {/* Contenedor principal del mensaje */}
      <div className="max-w-2xl mx-auto px-4 py-16 relative z-10">
        <div className="bg-white/10 backdrop-blur-md p-8 rounded-2xl border border-white/30 text-center">
          {/* Icono de éxito */}
          <div className="bg-dohmi-orange/10 p-4 rounded-full w-16 h-16 mx-auto mb-6 flex items-center justify-center">
            <Send size={32} className="text-dohmi-orange" />
          </div>
          
          {/* Mensaje personalizado */}
          <h3 className="text-2xl font-display font-bold text-dohmi-copper mb-4">
            ¡Gracias por contactarnos, {userName}!
          </h3>
          <p className="text-dohmi-copper/90 mb-6">
            Nuestro equipo de asesores expertos se pondrá en contacto contigo
            pronto para brindarte la asesoría personalizada que necesitas.
          </p>
          
          {/* Separador decorativo */}
          <div className="w-24 h-1 bg-dohmi-orange mx-auto mb-6"></div>
          
          {/* Botón para volver al inicio */}
          <button
            onClick={() => (window.location.href = '/')}
            className="group bg-dohmi-copper hover:bg-dohmi-orange text-dohmi-cream px-6 py-3 rounded-xl transition duration-300 transform hover:scale-105 flex items-center justify-center mx-auto border border-white/30"
          >
            <Home size={20} className="mr-2" />
            <span>Volver al inicio</span>
          </button>
        </div>
      </div>
    </div>
  );
};