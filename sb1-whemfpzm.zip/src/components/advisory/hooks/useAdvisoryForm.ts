import { useState, useEffect } from 'react';
import { saveAdvisoryRequest } from '../../../lib/supabase';
import { mexicoStates } from '../../../data/mexicoLocations';

// Define la estructura de los datos del formulario
interface FormData {
  name: string;        // Nombre completo del usuario
  position: string;    // Cargo o puesto en la empresa
  company: string;     // Nombre de la empresa
  city: string;        // Ciudad seleccionada
  state: string;       // Estado seleccionado
  phone: string;       // Número telefónico (sin código de país)
  country_code: string; // Código de país para el teléfono
}

// Define la estructura de los errores del formulario
interface FormErrors {
  name?: string;       // Error en el campo nombre
  position?: string;   // Error en el campo cargo
  company?: string;    // Error en el campo empresa
  city?: string;       // Error en el campo ciudad
  state?: string;      // Error en el campo estado
  phone?: string;      // Error en el campo teléfono
}

// Define el estado completo del formulario
interface AdvisoryFormState {
  formData: FormData;              // Datos del formulario
  formErrors: FormErrors;          // Errores de validación
  isSubmitted: boolean;            // Indica si el formulario fue enviado
  stateOptions: string[];         // Lista de estados filtrados para autocompletar
  cityOptions: string[];          // Lista de ciudades filtradas para autocompletar
  showStateDropdown: boolean;     // Controla la visibilidad del dropdown de estados
  showCityDropdown: boolean;      // Controla la visibilidad del dropdown de ciudades
  showCountryDropdown: boolean;   // Controla la visibilidad del dropdown de códigos de país
}

export const useAdvisoryForm = () => {
  // Inicializa el estado del formulario con valores por defecto
  const [state, setState] = useState<AdvisoryFormState>({
    formData: {
      name: '',
      position: '',
      company: '',
      city: '',
      state: '',
      phone: '',
      country_code: '+52', // Código por defecto para México
    },
    formErrors: {},
    isSubmitted: false,
    stateOptions: [],
    cityOptions: [],
    showStateDropdown: false,
    showCityDropdown: false,
    showCountryDropdown: false,
  });

  // Valida todos los campos del formulario
  const validateForm = (): boolean => {
    const errors: FormErrors = {};
    
    // Validación del nombre: requerido y solo letras
    if (!state.formData.name.trim()) {
      errors.name = 'El nombre es requerido';
    } else if (!/^[A-Za-zÀ-ÿ\s]+$/.test(state.formData.name)) {
      errors.name = 'El nombre solo debe contener letras';
    }

    // Validación del cargo: requerido
    if (!state.formData.position.trim()) {
      errors.position = 'El cargo es requerido';
    }

    // Validación de la empresa: requerida
    if (!state.formData.company.trim()) {
      errors.company = 'La empresa es requerida';
    }

    // Validación del estado: requerido
    if (!state.formData.state) {
      errors.state = 'El estado es requerido';
    }

    // Validación de la ciudad: requerida
    if (!state.formData.city) {
      errors.city = 'La ciudad es requerida';
    }

    // Validación del teléfono: requerido y formato específico
    if (!state.formData.phone.trim()) {
      errors.phone = 'El teléfono es requerido';
    } else if (!/^\d{10}$/.test(state.formData.phone)) {
      errors.phone = 'El teléfono debe tener 10 dígitos';
    }

    // Actualiza el estado con los errores encontrados
    setState(prev => ({ ...prev, formErrors: errors }));
    return Object.keys(errors).length === 0; // Retorna true si no hay errores
  };

  // Maneja los cambios en los campos del formulario
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    let processedValue = value;

    // Procesamiento especial para campos específicos
    if (name === 'name') {
      // Remueve caracteres no permitidos en el nombre
      processedValue = value.replace(/[^A-Za-zÀ-ÿ\s]/g, '');
    } else if (name === 'phone') {
      // Remueve caracteres no numéricos y limita a 10 dígitos
      processedValue = value.replace(/\D/g, '').slice(0, 10);
    }

    setState(prev => {
      const newState = {
        ...prev,
        formData: { ...prev.formData, [name]: processedValue },
        formErrors: { ...prev.formErrors, [name]: undefined },
      };

      // Manejo especial para el campo estado
      if (name === 'state') {
        // Filtra los estados que coinciden con la búsqueda
        const filteredStates = mexicoStates
          .filter(state => state.name.toLowerCase().includes(value.toLowerCase()))
          .map(state => state.name);

        newState.stateOptions = filteredStates;
        newState.showStateDropdown = true;
        newState.formData.city = ''; // Limpia la ciudad al cambiar el estado
        newState.cityOptions = [];
      }

      // Manejo especial para el campo ciudad
      if (name === 'city' && prev.formData.state) {
        // Filtra las ciudades del estado seleccionado
        const selectedState = mexicoStates.find(
          state => state.name === prev.formData.state
        );
        if (selectedState) {
          const filteredCities = selectedState.cities
            .filter(city => city.name.toLowerCase().includes(value.toLowerCase()))
            .map(city => city.name);
          newState.cityOptions = filteredCities;
          newState.showCityDropdown = true;
        }
      }

      return newState;
    });
  };

  // Maneja la selección de un estado del dropdown
  const handleStateSelect = (stateName: string) => {
    setState(prev => ({
      ...prev,
      formData: { ...prev.formData, state: stateName, city: '' },
      showStateDropdown: false,
      cityOptions: [],
    }));
  };

  // Maneja la selección de una ciudad del dropdown
  const handleCitySelect = (cityName: string) => {
    setState(prev => ({
      ...prev,
      formData: { ...prev.formData, city: cityName },
      showCityDropdown: false,
    }));
  };

  // Maneja la selección de un código de país
  const handleCountrySelect = (code: string) => {
    setState(prev => ({
      ...prev,
      formData: { ...prev.formData, country_code: code },
      showCountryDropdown: false,
    }));
  };

  // Alterna la visibilidad del dropdown de códigos de país
  const toggleCountryDropdown = () => {
    setState(prev => ({
      ...prev,
      showCountryDropdown: !prev.showCountryDropdown,
    }));
  };

  // Maneja el envío del formulario
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Valida el formulario antes de enviarlo
    if (!validateForm()) {
      return;
    }

    try {
      // Guarda los datos en Supabase
      await saveAdvisoryRequest(state.formData);
      setState(prev => ({ ...prev, isSubmitted: true }));
    } catch (error) {
      console.error('Error saving form:', error);
      alert('Hubo un error al enviar el formulario. Por favor, intente nuevamente.');
    }
  };

  // Efecto para cerrar los dropdowns al hacer clic fuera de ellos
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      if (!target.closest('.location-dropdown')) {
        setState(prev => ({
          ...prev,
          showStateDropdown: false,
          showCityDropdown: false,
          showCountryDropdown: false,
        }));
      }
    };

    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  // Expone las funciones y el estado necesarios para el componente
  return {
    state,
    handleInputChange,
    handleStateSelect,
    handleCitySelect,
    handleCountrySelect,
    toggleCountryDropdown,
    handleSubmit,
  };
};