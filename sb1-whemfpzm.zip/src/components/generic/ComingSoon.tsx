import React from 'react';
import { useTranslation } from 'react-i18next';
import { Clock } from 'lucide-react';
import ArtDecoPattern from '../reactbits/ArtDecoPattern';

export default function ComingSoon() {
  const { t } = useTranslation();

  return (
    <div className="min-h-screen pt-20 relative">
      <div className="absolute inset-0 z-0">
        <ArtDecoPattern
          direction="diagonal"
          speed={0.5}
          primaryColor="rgb(255, 87, 5,0.3)"
          secondaryColor="rgb(255, 87, 5,0.3)"
          patternSize={150}
        />
      </div>
      <div className="max-w-2xl mx-auto px-4 py-16 relative z-10">
        <div className="bg-white/10 backdrop-blur-md p-8 rounded-2xl border border-white/30 text-center">
          <div className="bg-dohmi-orange/10 p-4 rounded-full w-16 h-16 mx-auto mb-6 flex items-center justify-center">
            <Clock size={32} className="text-dohmi-orange" />
          </div>
          <h3 className="text-4xl md:text-5xl font-display font-bold text-dohmi-orange mb-4">
            Próximamente
          </h3>
          <p className="text-xl text-dohmi-copper/90 mb-6">
            Estamos trabajando para brindarte la mejor experiencia inmobiliaria.
          </p>
          <div className="w-24 h-1 bg-dohmi-orange mx-auto"></div>
        </div>
      </div>
    </div>
  );
}