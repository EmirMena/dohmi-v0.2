import React from 'react';
import { useTranslation } from 'react-i18next';
import { Search, Home, ArrowRight } from 'lucide-react';
import QuestionnaireForm from './QuestionnaireForm';

export default function Hero() {
  const { t } = useTranslation();

  return (
    <div className="relative min-h-screen">
      {/* Hero Background */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage:
            'url("https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=2000")',
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-dohmi-copper/90 to-black/50"></div>
      </div>

      {/* Hero Content */}
      <div className="relative min-h-screen flex items-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full py-12 lg:py-0">
          <div className="grid lg:grid-cols-2 gap-12 items-start lg:items-center">
            {/* Hero Text and CTA Buttons */}
            <div className="text-left space-y-8">
              <h1 className="text-4xl sm:text-5xl md:text-7xl font-display font-bold text-white leading-tight">
                {t('hero.title')}
              </h1>
              <p className="text-xl md:text-2xl text-dohmi-cream/90 max-w-xl">
                {t('hero.subtitle')}
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <button className="group bg-dohmi-orange hover:bg-dohmi-yellow text-white px-8 py-4 rounded-xl flex items-center justify-center transition duration-300 transform hover:scale-105">
                  <Search size={20} className="mr-2" />
                  <span>{t('cta.explore')}</span>
                  <ArrowRight
                    size={20}
                    className="ml-2 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-x-[-10px] group-hover:translate-x-0"
                  />
                </button>
                <button className="group bg-white/10 hover:bg-white/20 backdrop-blur-md text-white px-8 py-4 rounded-xl flex items-center justify-center transition duration-300 transform hover:scale-105 border border-white/30">
                  <Home size={20} className="mr-2" />
                  <span>{t('cta.publish')}</span>
                  <ArrowRight
                    size={20}
                    className="ml-2 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-x-[-10px] group-hover:translate-x-0"
                  />
                </button>
              </div>
            </div>

            {/* Questionnaire Form - Now visible on all screen sizes */}
            <div className="w-full max-w-lg mx-auto lg:mx-0">
              <QuestionnaireForm />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}