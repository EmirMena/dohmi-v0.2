import React from 'react';
import { Search } from 'lucide-react';

export default function PropertySearchForm() {
  return (
    <div className="bg-white/10 backdrop-blur-md p-8 rounded-2xl border border-white/30">
      <form className="space-y-4">
        {/* Property Type Selection */}
        <div className="grid grid-cols-2 gap-4">
          <select className="w-full px-4 py-3 rounded-xl bg-white/10 border border-white/30 text-white focus:outline-none focus:ring-2 focus:ring-dohmi-orange">
            <option value="buy">Comprar</option>
            <option value="rent">Rentar</option>
          </select>
          <select className="w-full px-4 py-3 rounded-xl bg-white/10 border border-white/30 text-white focus:outline-none focus:ring-2 focus:ring-dohmi-orange">
            <option value="house">Casa</option>
            <option value="apartment">Departamento</option>
            <option value="office">Oficina</option>
          </select>
        </div>

        {/* Location Input */}
        <input
          type="text"
          placeholder="Ubicación"
          className="w-full px-4 py-3 rounded-xl bg-white/10 border border-white/30 text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-dohmi-orange"
        />

        {/* Price Range */}
        <div className="grid grid-cols-2 gap-4">
          <input
            type="number"
            placeholder="Precio Min"
            className="w-full px-4 py-3 rounded-xl bg-white/10 border border-white/30 text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-dohmi-orange"
          />
          <input
            type="number"
            placeholder="Precio Max"
            className="w-full px-4 py-3 rounded-xl bg-white/10 border border-white/30 text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-dohmi-orange"
          />
        </div>

        {/* Search Button */}
        <button className="w-full bg-dohmi-orange hover:bg-dohmi-yellow text-white px-6 py-3 rounded-xl transition duration-300 transform hover:scale-105 flex items-center justify-center">
          <Search size={20} className="mr-2" />
          Buscar Propiedades
        </button>
      </form>
    </div>
  );
}