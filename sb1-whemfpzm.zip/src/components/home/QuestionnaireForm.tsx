import React from 'react';
import { useQuestionnaire } from './questionnaire/hooks/useQuestionnaire';
import { ProgressIndicator } from './questionnaire/components/ProgressIndicator';
import { QuestionDisplay } from './questionnaire/components/QuestionDisplay';
import { PhoneInput } from './questionnaire/components/PhoneInput';
import { CompletionMessage } from './questionnaire/components/CompletionMessage';

/**
 * Componente principal del formulario de cuestionario
 * Este componente maneja la lógica de navegación y estado del cuestionario,
 * delegando la renderización a componentes más específicos
 */
export default function QuestionnaireForm() {
  const {
    state,
    getCurrentQuestion,
    handleAnswer,
    handlePhoneSubmit,
    handleRestart,
    handleBack,
    setState,
  } = useQuestionnaire();

  // Si el cuestionario está completado, mostrar el mensaje de finalización
  if (state.isCompleted) {
    return <CompletionMessage onRestart={handleRestart} />;
  }

  // Si se está mostrando el input de teléfono
  if (state.showPhoneInput) {
    return (
      <PhoneInput
        phoneNumber={state.phoneNumber}
        countryCode={state.countryCode}
        showCountryDropdown={state.showCountryDropdown}
        onPhoneChange={(value) => setState(prev => ({ ...prev, phoneNumber: value }))}
        onCountryCodeChange={(code) => setState(prev => ({ 
          ...prev, 
          countryCode: code,
          showCountryDropdown: false,
        }))}
        onToggleDropdown={() => setState(prev => ({ 
          ...prev,
          showCountryDropdown: !prev.showCountryDropdown,
        }))}
        onSubmit={handlePhoneSubmit}
        onBack={() => {
          setState(prev => ({
            ...prev,
            showPhoneInput: false,
            currentQuestion: prev.currentQuestion - 1,
          }));
        }}
      />
    );
  }

  // Obtener la pregunta actual y calcular el total de pasos
  const currentQ = getCurrentQuestion();
  const totalSteps = state.answers[1] === 'family' ? 5 : 4;

  // Renderizar el formulario principal
  return (
    <div className="bg-white/10 backdrop-blur-md p-8 rounded-2xl border border-white/30">
      <ProgressIndicator
        currentQuestion={state.currentQuestion}
        totalSteps={totalSteps}
      />
      <QuestionDisplay
        question={currentQ}
        onAnswer={handleAnswer}
        onBack={handleBack}
        showBackButton={state.currentQuestion > 0}
      />
    </div>
  );
}