import React from 'react';
import { ArrowRight } from 'lucide-react';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface ServiceCardProps {
  Icon: LucideIcon;
  title: string;
  description: string;
  ctaText: string;
  imageUrl: string;
  navigateTo: string;
}

export default function ServiceCard({
  Icon,
  title,
  description,
  ctaText,
  imageUrl,
  navigateTo,
}: ServiceCardProps) {
  // Get the navigate function from the parent component
  const handleNavigation = () => {
    // Dispatch a custom event that App.tsx will listen to
    window.dispatchEvent(new CustomEvent('navigate', { detail: navigateTo }));
  };

  return (
    <div className="group relative bg-white rounded-2xl p-8 shadow-xl transform transition duration-300 hover:scale-105 hover:rotate-1 overflow-hidden">
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-dohmi-orange/5 to-dohmi-yellow/5 rounded-2xl transform transition duration-300 group-hover:scale-105 -z-10"></div>

      {/* Service Image */}
      <div className="relative h-48 -mx-8 -mt-8 mb-6 overflow-hidden">
        <img
          src={imageUrl}
          alt={title}
          className="w-full h-full object-cover transform transition duration-300 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-white via-white/20 to-transparent"></div>
      </div>

      {/* Icon */}
      <div className="bg-dohmi-orange/10 p-4 rounded-xl inline-block mb-6">
        <Icon size={32} className="text-dohmi-orange" />
      </div>

      {/* Content */}
      <h3 className="text-2xl font-display font-bold text-dohmi-copper mb-4">
        {title}
      </h3>
      <p className="text-gray-600 mb-6">{description}</p>

      {/* CTA Button */}
      <button 
        onClick={handleNavigation}
        className="group/btn flex items-center text-dohmi-orange hover:text-dohmi-yellow transition duration-300"
      >
        <span className="mr-2">{ctaText}</span>
        <ArrowRight
          size={20}
          className="transform transition duration-300 group-hover/btn:translate-x-2"
        />
      </button>
    </div>
  );
}