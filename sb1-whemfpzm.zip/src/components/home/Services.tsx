import React from 'react';
import { useTranslation } from 'react-i18next';
import ServiceCard from './ServiceCard';
import { UserCheck, Home, Key } from 'lucide-react';
import ArtDecoPattern from '../reactbits/ArtDecoPattern';

interface ServiceCardData {
  icon: typeof UserCheck;
  title: string;
  description: string;
  ctaText: string;
  imageUrl: string;
  navigateTo: string;
}

export default function Services() {
  const { t } = useTranslation();

  const services: ServiceCardData[] = [
    {
      icon: UserCheck,
      title: 'services.advisory.title',
      description: 'services.advisory.description',
      ctaText: 'cta.consult',
      imageUrl: 'https://images.unsplash.com/photo-1600880292203-757bb62b4baf?auto=format&fit=crop&q=80&w=800',
      navigateTo: 'advisory'
    },
    {
      icon: Home,
      title: 'services.properties.title',
      description: 'services.properties.description',
      ctaText: 'cta.explore',
      imageUrl: 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&q=80&w=800',
      navigateTo: 'buy'
    },
    {
      icon: Key,
      title: 'services.sell.title',
      description: 'services.sell.description',
      ctaText: 'cta.publish',
      imageUrl: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&q=80&w=800',
      navigateTo: 'sell'
    },
  ];

  return (
    <div className="py-24 relative overflow-hidden">
      {/* Animated Art Deco Background */}
      <div className="absolute inset-0 z-10">
        <ArtDecoPattern
          direction="down"
          speed={0.3}
          primaryColor='rgb(255, 87, 5,0.3)'
          secondaryColor='rgb(255, 87, 5,0.3)'
          patternSize={190}
          hoverFillColor="rgba(0, 0, 0, 0.0)"
        />
      </div>
  
      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-20">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-display font-bold text-dohmi-copper mb-4">
            {t('services.title')}
          </h2>
          <div className="w-24 h-1 bg-dohmi-orange mx-auto"></div>
        </div>
  
        {/* Services Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <ServiceCard
              key={index}
              Icon={service.icon}
              title={t(service.title)}
              description={t(service.description)}
              ctaText={t(service.ctaText)}
              imageUrl={service.imageUrl}
              navigateTo={service.navigateTo}
            />
          ))}
        </div>
      </div>
    </div>
  );
}