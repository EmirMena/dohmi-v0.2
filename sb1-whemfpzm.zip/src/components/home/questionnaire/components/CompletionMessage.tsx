import React from 'react';
import { Send, RefreshCw } from 'lucide-react';
import { useTranslation } from 'react-i18next';

interface CompletionMessageProps {
  onRestart: () => void;
}

// Componente para mostrar el mensaje de finalización
export const CompletionMessage: React.FC<CompletionMessageProps> = ({ onRestart }) => {
  const { t } = useTranslation();

  return (
    <div className="bg-white/10 backdrop-blur-md p-8 rounded-2xl border border-white/30 text-center">
      <div className="bg-dohmi-orange/10 p-4 rounded-full w-16 h-16 mx-auto mb-6 flex items-center justify-center">
        <Send size={32} className="text-dohmi-orange" />
      </div>
      <h3 className="text-2xl font-display font-bold text-white mb-4">
        {t('Questionnaire.thanks.title')}
      </h3>
      <p className="text-white/90 mb-6">{t('Questionnaire.thanks.text')}</p>
      <div className="w-24 h-1 bg-dohmi-orange mx-auto mb-6"></div>
      <button
        onClick={onRestart}
        className="group bg-white/10 hover:bg-white/20 text-white px-6 py-3 rounded-xl transition duration-300 transform hover:scale-105 flex items-center justify-center mx-auto border border-white/30"
      >
        <RefreshCw
          size={20}
          className="mr-2 group-hover:rotate-180 transition-transform duration-500"
        />
        <span>{t('Questionnaire.thanks.button')}</span>
      </button>
    </div>
  );
};