import React from 'react';
import { Phone, ChevronDown, ArrowLeft, ArrowRight } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { countryCodes } from '../../../../data/countryCodes';
import { PhoneInputProps } from '../types';

// Componente para la entrada del número telefónico
export const PhoneInput: React.FC<PhoneInputProps> = ({
  phoneNumber,
  countryCode,
  showCountryDropdown,
  onPhoneChange,
  onCountryCodeChange,
  onToggleDropdown,
  onSubmit,
  onBack,
}) => {
  const { t } = useTranslation();

  return (
    <div className="bg-white/10 backdrop-blur-md p-8 rounded-2xl border border-white/30">
      <h3 className="text-xl font-display text-white mb-6">
        {t('Questionnaire.contact.title')}
      </h3>
      <p className="text-white/80 mb-6">
        {t('Questionnaire.contact.description')}
      </p>
      <form onSubmit={onSubmit} className="space-y-6">
        <div className="flex gap-4">
          <div className="relative w-1/3 country-dropdown">
            <button
              type="button"
              onClick={onToggleDropdown}
              className="w-full pl-12 pr-4 py-3 bg-white/10 border border-white/30 rounded-xl text-white focus:outline-none focus:border-dohmi-orange focus:ring-2 focus:ring-dohmi-orange/50 flex items-center justify-between"
            >
              <Phone size={20} className="absolute left-4 top-1/2 transform -translate-y-1/2 text-dohmi-orange" />
              <span>{countryCodes.find(c => c.code === countryCode)?.flag} {countryCode}</span>
              <ChevronDown size={16} className={`transition-transform duration-200 ${showCountryDropdown ? 'rotate-180' : ''}`} />
            </button>
            {showCountryDropdown && (
              <div className="absolute z-10 w-full mt-1 bg-dohmi-copper/90 backdrop-blur-md border border-white/30 rounded-xl max-h-48 overflow-y-auto">
                {countryCodes.map((country, index) => (
                  <button
                    key={index}
                    type="button"
                    onClick={() => onCountryCodeChange(country.code)}
                    className="w-full px-4 py-2 text-white hover:bg-white/20 flex items-center space-x-2 text-left"
                  >
                    <span>{country.flag}</span>
                    <span>{country.code}</span>
                    <span className="text-sm text-white/70">{country.country}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
          <div className="relative flex-1">
            <input
              type="tel"
              value={phoneNumber}
              onChange={(e) => onPhoneChange(e.target.value)}
              placeholder={t('Questionnaire.contact.placeholder')}
              className="w-full px-4 py-3 bg-white/10 border border-white/30 rounded-xl text-white placeholder-white/70 focus:outline-none focus:border-dohmi-orange focus:ring-2 focus:ring-dohmi-orange/50"
              required
            />
          </div>
        </div>
        <div className="flex gap-4">
          <button
            type="button"
            onClick={onBack}
            className="flex-1 bg-white/10 hover:bg-white/20 text-white px-6 py-4 rounded-xl transition duration-300 transform hover:scale-105 flex items-center justify-center group border border-white/30"
          >
            <ArrowLeft
              size={20}
              className="mr-2 transform transition-all duration-300 group-hover:-translate-x-2"
            />
            <span>{t('Questionnaire.navigation.back')}</span>
          </button>
          <button
            type="submit"
            className="flex-1 bg-dohmi-orange hover:bg-dohmi-yellow text-white px-6 py-4 rounded-xl transition duration-300 transform hover:scale-105 flex items-center justify-center group"
          >
            <span>{t('Questionnaire.contact.button')}</span>
            <ArrowRight
              size={20}
              className="ml-2 opacity-0 group-hover:opacity-100 transform translate-x-[-10px] group-hover:translate-x-0 transition-all duration-300"
            />
          </button>
        </div>
      </form>
    </div>
  );
};