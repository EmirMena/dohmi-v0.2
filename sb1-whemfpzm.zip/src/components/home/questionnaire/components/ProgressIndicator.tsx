import React from 'react';
import { Check } from 'lucide-react';
import { ProgressIndicatorProps } from '../types';

// Componente para mostrar el indicador de progreso del cuestionario
export const ProgressIndicator: React.FC<ProgressIndicatorProps> = ({
  currentQuestion,
  totalSteps,
}) => (
  <div className="flex justify-between mb-8">
    {Array.from({ length: totalSteps }, (_, index) => (
      <div
        key={index}
        className={`flex items-center ${index > 0 ? 'flex-1' : ''}`}
      >
        <div
          className={`w-8 h-8 rounded-full flex items-center justify-center ${
            index < currentQuestion
              ? 'bg-dohmi-orange text-white'
              : index === currentQuestion
              ? 'bg-white/20 text-white border-2 border-dohmi-orange'
              : 'bg-white/20 text-white'
          }`}
        >
          {index < currentQuestion ? <Check size={16} /> : index + 1}
        </div>
        {index < totalSteps - 1 && (
          <div
            className={`flex-1 h-1 mx-2 ${
              index < currentQuestion ? 'bg-dohmi-orange' : 'bg-white/20'
            }`}
          />
        )}
      </div>
    ))}
  </div>
);