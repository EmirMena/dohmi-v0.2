import React from 'react';
import { ArrowRight, ArrowLeft } from 'lucide-react';
import { QuestionDisplayProps } from '../types';

// Componente para mostrar una pregunta individual y sus opciones
export const QuestionDisplay: React.FC<QuestionDisplayProps> = ({
  question,
  onAnswer,
  onBack,
  showBackButton,
}) => (
  <>
    <h3 className="text-xl font-display text-white mb-6">{question.text}</h3>
    <div className="space-y-4">
      {question.options.map((option) => (
        <button
          key={option.value}
          onClick={() => onAnswer(question.id, option.value)}
          className="w-full bg-white/10 hover:bg-white/20 text-white px-6 py-4 rounded-xl transition duration-300 transform hover:scale-105 flex items-center justify-between group border border-white/30"
        >
          <span>{option.label}</span>
          <ArrowRight
            size={20}
            className="opacity-0 group-hover:opacity-100 transform translate-x-[-10px] group-hover:translate-x-0 transition-all duration-300"
          />
        </button>
      ))}
    </div>

    {showBackButton && (
      <button
        onClick={onBack}
        className="mt-6 w-full bg-white/10 hover:bg-white/20 text-white px-6 py-4 rounded-xl transition duration-300 transform hover:scale-105 flex items-center justify-center group border border-white/30"
      >
        <ArrowLeft
          size={20}
          className="mr-2 transform transition-all duration-300 group-hover:-translate-x-2"
        />
        <span>Pregunta Anterior</span>
      </button>
    )}
  </>
);