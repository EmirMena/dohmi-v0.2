import { useTranslation } from 'react-i18next';
import { Question, FamilyPath, QuestionPath } from './types';

// Hook personalizado para obtener las preguntas con traducciones
export const useQuestionnaireConstants = () => {
  const { t } = useTranslation();

  // Pregunta inicial para todos los usuarios
  const initialQuestion: Question = {
    id: 1,
    text: t('Questionnaire.purpose.question'),
    options: [
      { value: 'family', label: t('Questionnaire.purpose.family') },
      { value: 'investment', label: t('Questionnaire.purpose.investment') },
      { value: 'vacation', label: t('Questionnaire.purpose.vacation') },
      { value: 'student', label: t('Questionnaire.purpose.student') },
    ],
  };

  // Ruta de preguntas para familias
  const familyPath: FamilyPath = {
    intention: {
      id: 2,
      text: t('Questionnaire.intention.question'),
      options: [
        { value: 'buy', label: t('Questionnaire.intention.buy') },
        { value: 'rent', label: t('Questionnaire.intention.rent') },
      ],
    },
    timeframe: {
      id: 3,
      text: t('Questionnaire.timeframe.question'),
      options: [
        { value: 'immediate', label: t('Questionnaire.timeframe.immediate') },
        { value: 'short', label: t('Questionnaire.timeframe.short') },
        { value: 'medium', label: t('Questionnaire.timeframe.medium') },
        { value: 'planning', label: t('Questionnaire.timeframe.planning') },
      ],
    },
    lifestyle: {
      id: 4,
      text: t('Questionnaire.lifestyle.question'),
      options: [
        { value: 'school', label: t('Questionnaire.lifestyle.school') },
        { value: 'suburban', label: t('Questionnaire.lifestyle.suburban') },
        { value: 'gated', label: t('Questionnaire.lifestyle.gated') },
        { value: 'nature', label: t('Questionnaire.lifestyle.nature') },
      ],
    },
    budget: {
      id: 5,
      text: t('Questionnaire.budget.question'),
      options: [
        { value: 'starter', label: t('Questionnaire.budget.starter_buy') },
        { value: 'mid', label: t('Questionnaire.budget.mid_buy') },
        { value: 'high', label: t('Questionnaire.budget.high_buy') },
        { value: 'luxury', label: t('Questionnaire.budget.luxury_buy') },
      ],
    },
  };

// Rutas de preguntas para los demás propósitos
const questionPaths: QuestionPath = {
  investment: {
    timeframe: {
      id: 2,
      text:    t('Questionnaire.investment.timeframe.question'),
      options: [
        { value: 'short',  label: t('Questionnaire.investment.timeframe.short')  },
        { value: 'medium', label: t('Questionnaire.investment.timeframe.medium') },
        { value: 'long',   label: t('Questionnaire.investment.timeframe.long')   },
        { value: 'flip',   label: t('Questionnaire.investment.timeframe.flip')   },
      ],
    },
    lifestyle: {
      id: 3,
      text:    t('Questionnaire.investment.type.question'),
      options: [
        { value: 'residential', label: t('Questionnaire.investment.type.residential') },
        { value: 'commercial',  label: t('Questionnaire.investment.type.commercial')  },
        { value: 'mixed',       label: t('Questionnaire.investment.type.mixed')       },
        { value: 'land',        label: t('Questionnaire.investment.type.land')        },
      ],
    },
    budget: {
      id: 4,
      text:    t('Questionnaire.investment.budget.question'),
      options: [
        { value: 'small',       label: t('Questionnaire.investment.budget.small')       },
        { value: 'medium',      label: t('Questionnaire.investment.budget.medium')      },
        { value: 'large',       label: t('Questionnaire.investment.budget.large')       },
        { value: 'institutional',label: t('Questionnaire.investment.budget.institutional') },
      ],
    },
  },
  vacation: {
    timeframe: {
      id: 2,
      text:    t('Questionnaire.vacation.frequency.question'),
      options: [
        { value: 'weekends',   label: t('Questionnaire.vacation.frequency.weekends')   },
        { value: 'seasonal',   label: t('Questionnaire.vacation.frequency.seasonal')   },
        { value: 'occasional', label: t('Questionnaire.vacation.frequency.occasional') },
        { value: 'rental',     label: t('Questionnaire.vacation.frequency.rental')     },
      ],
    },
    lifestyle: {
      id: 3,
      text:    t('Questionnaire.vacation.location.question'),
      options: [
        { value: 'beach',     label: t('Questionnaire.vacation.location.beach')     },
        { value: 'mountain',  label: t('Questionnaire.vacation.location.mountain')  },
        { value: 'colonial',  label: t('Questionnaire.vacation.location.colonial')  },
        { value: 'resort',    label: t('Questionnaire.vacation.location.resort')    },
      ],
    },
    budget: {
      id: 4,
      text:    t('Questionnaire.vacation.budget.question'),
      options: [
        { value: 'modest',   label: t('Questionnaire.vacation.budget.modest')   },
        { value: 'comfort',  label: t('Questionnaire.vacation.budget.comfort')  },
        { value: 'luxury',   label: t('Questionnaire.vacation.budget.luxury')   },
        { value: 'elite',    label: t('Questionnaire.vacation.budget.elite')    },
      ],
    },
  },
  student: {
    timeframe: {
      id: 2,
      text:    t('Questionnaire.student.timeframe.question'),
      options: [
        { value: 'immediate', label: t('Questionnaire.student.timeframe.immediate') },
        { value: 'next',      label: t('Questionnaire.student.timeframe.next')      },
        { value: 'planning',  label: t('Questionnaire.student.timeframe.planning')  },
        { value: 'flexible',  label: t('Questionnaire.student.timeframe.flexible')  },
      ],
    },
    lifestyle: {
      id: 3,
      text:    t('Questionnaire.student.type.question'),
      options: [
        { value: 'studio',     label: t('Questionnaire.student.type.studio')     },
        { value: 'shared',     label: t('Questionnaire.student.type.shared')     },
        { value: 'residence',  label: t('Questionnaire.student.type.residence')  },
        { value: 'house',      label: t('Questionnaire.student.type.house')      },
      ],
    },
    budget: {
      id: 4,
      text:    t('Questionnaire.student.budget.question'),
      options: [
        { value: 'basic',    label: t('Questionnaire.student.budget.basic')    },
        { value: 'standard', label: t('Questionnaire.student.budget.standard') },
        { value: 'comfort',  label: t('Questionnaire.student.budget.comfort')  },
        { value: 'premium',  label: t('Questionnaire.student.budget.premium')  },
      ],
    },
  },
};

  return {
    initialQuestion,
    familyPath,
    questionPaths,
  };
};