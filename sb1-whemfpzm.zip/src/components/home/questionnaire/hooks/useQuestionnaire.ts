import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { QuestionnaireState, Question } from '../types';
import { useQuestionnaireConstants } from '../constants';
import { guardarRespuestaCuestionario } from '../../../../lib/supabase';

// Hook personalizado para manejar la lógica del cuestionario
export const useQuestionnaire = () => {
  const { t } = useTranslation();
  const { initialQuestion, familyPath, questionPaths } = useQuestionnaireConstants();

  // Estado inicial del cuestionario
  const [state, setState] = useState<QuestionnaireState>({
    currentQuestion: 0,
    answers: {},
    isCompleted: false,
    phoneNumber: '',
    countryCode: '+52',
    showPhoneInput: false,
    showCountryDropdown: false,
  });

  // Obtener la pregunta actual basada en las respuestas previas
  const getCurrentQuestion = (): Question => {
    if (state.currentQuestion === 0) return initialQuestion;

    const firstAnswer = state.answers[1];
    if (!firstAnswer) return initialQuestion;

    if (firstAnswer === 'family') {
      switch (state.currentQuestion) {
        case 1: return familyPath.intention;
        case 2: return familyPath.timeframe;
        case 3: return familyPath.lifestyle;
        case 4: return familyPath.budget;
        default: return initialQuestion;
      }
    }

    const path = questionPaths[firstAnswer];
    switch (state.currentQuestion) {
      case 1: return path.timeframe;
      case 2: return path.lifestyle;
      case 3: return path.budget;
      default: return initialQuestion;
    }
  };

  // Manejar la respuesta a una pregunta
  const handleAnswer = (questionId: number, answer: string) => {
    setState(prev => {
      const newAnswers = { ...prev.answers, [questionId]: answer };
      const isFamily = newAnswers[1] === 'family';
      const maxQuestions = isFamily ? 4 : 3;

      return {
        ...prev,
        answers: newAnswers,
        currentQuestion: prev.currentQuestion < maxQuestions 
          ? prev.currentQuestion + 1 
          : prev.currentQuestion,
        showPhoneInput: prev.currentQuestion >= maxQuestions,
      };
    });
  };

  // Manejar el envío del formulario de teléfono
  const handlePhoneSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (state.countryCode && state.phoneNumber) {
      try {
        // Guardar las respuestas en Supabase
        await guardarRespuestaCuestionario(state.answers);

        // Construir y abrir el mensaje de WhatsApp
        const message = constructWhatsAppMessage();
        const formattedPhone = (state.countryCode + state.phoneNumber).replace(/\D/g, '');
        const whatsappUrl = `https://wa.me/${formattedPhone}?text=${encodeURIComponent(message)}`;
        
        window.open(whatsappUrl, '_blank');
        setState(prev => ({ ...prev, isCompleted: true }));
      } catch (error) {
        console.error('Error al guardar las respuestas:', error);
        // Aquí podrías mostrar un mensaje de error al usuario
      }
    }
  };

  // Construir el mensaje para WhatsApp
  const constructWhatsAppMessage = (): string => {
    const { answers } = state;
    const userType = answers[1];
    const timeframe = answers[2];
    const lifestyle = answers[3];
    const budget = answers[4];

    let message = `¡Hola! Me interesa recibir información sobre propiedades. Mis preferencias son:\n\n`;
    message += `- Busco para: ${t(`Questionnaire.purpose.${userType}`)}\n`;
    
    if (userType === 'family') {
      message += `- Intención: ${t(`Questionnaire.intention.${answers[2]}`)}\n`;
      message += `- Plazo: ${t(`Questionnaire.timeframe.${timeframe}`)}\n`;
      message += `- Estilo de vida: ${t(`Questionnaire.lifestyle.${lifestyle}`)}\n`;
      message += `- Presupuesto: ${t(`Questionnaire.budget.${budget}_${answers[2]}`)}\n`;
    } else {
      const path = userType as keyof typeof questionPaths;
      message += `- ${t(`Questionnaire.${path}.timeframe.${timeframe}`)}\n`;
      message += `- ${t(`Questionnaire.${path}.type.${lifestyle}`)}\n`;
      message += `- ${t(`Questionnaire.${path}.budget.${budget}`)}\n`;
    }

    return message;
  };

  // Reiniciar el cuestionario
  const handleRestart = () => {
    setState({
      currentQuestion: 0,
      answers: {},
      isCompleted: false,
      phoneNumber: '',
      countryCode: '+52',
      showPhoneInput: false,
      showCountryDropdown: false,
    });
  };

  // Manejar el botón de retroceso
  const handleBack = () => {
    if (state.currentQuestion > 0) {
      setState(prev => {
        const newAnswers = { ...prev.answers };
        delete newAnswers[getCurrentQuestion().id];
        return {
          ...prev,
          currentQuestion: prev.currentQuestion - 1,
          answers: newAnswers,
          showPhoneInput: false,
        };
      });
    }
  };

  // Efecto para manejar clics fuera del dropdown de países
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      if (!target.closest('.country-dropdown')) {
        setState(prev => ({ ...prev, showCountryDropdown: false }));
      }
    };

    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  return {
    state,
    getCurrentQuestion,
    handleAnswer,
    handlePhoneSubmit,
    handleRestart,
    handleBack,
    setState,
  };
};