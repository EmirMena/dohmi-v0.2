// Tipos comunes para el cuestionario
export interface Option {
  value: string;
  label: string;
}

export interface Question {
  id: number;
  text: string;
  options: Option[];
}

export interface FamilyPath {
  intention: Question;
  timeframe: Question;
  lifestyle: Question;
  budget: Question;
}

export interface QuestionPath {
  [key: string]: {
    timeframe: Question;
    lifestyle: Question;
    budget: Question;
  };
}

// Tipos para los estados del formulario
export interface QuestionnaireState {
  currentQuestion: number;
  answers: Record<number, string>;
  isCompleted: boolean;
  phoneNumber: string;
  countryCode: string;
  showPhoneInput: boolean;
  showCountryDropdown: boolean;
}

// Tipos para las props de los componentes
export interface ProgressIndicatorProps {
  currentQuestion: number;
  totalSteps: number;
}

export interface QuestionDisplayProps {
  question: Question;
  onAnswer: (questionId: number, answer: string) => void;
  onBack: () => void;
  showBackButton: boolean;
}

export interface PhoneInputProps {
  phoneNumber: string;
  countryCode: string;
  showCountryDropdown: boolean;
  onPhoneChange: (value: string) => void;
  onCountryCodeChange: (code: string) => void;
  onToggleDropdown: () => void;
  onSubmit: (e: React.FormEvent) => void;
  onBack: () => void;
}