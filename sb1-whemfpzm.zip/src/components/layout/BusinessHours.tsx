import React from 'react';
import { useTranslation } from 'react-i18next';
import { Clock } from 'lucide-react';

export default function BusinessHours() {
  const { t } = useTranslation();

  return (
    <div className="space-y-6">
      <h4 className="font-display text-2xl text-dohmi-orange">
        {t('footer.hours.label')}
      </h4>
      <ul className="space-y-4">
        <li className="flex items-center space-x-3">
          <Clock size={20} className="text-dohmi-orange" />
          <span>{t('footer.hours.weekdays')}</span>
        </li>
        <li className="flex items-center space-x-3">
          <Clock size={20} className="text-dohmi-orange" />
          <span>{t('footer.hours.saturday')}</span>
        </li>
      </ul>
    </div>
  );
}
