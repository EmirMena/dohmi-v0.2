import React from 'react';
import { Mail, Phone, MapPin } from 'lucide-react';

export default function ContactInfo() {
  return (
    <div className="space-y-6">
      <h4 className="font-display text-3xl text-dohmi-orange">DOHMI</h4>
      <ul className="space-y-4">
        <li className="group flex items-center space-x-3 hover:text-dohmi-orange transition-colors">
          <Mail size={20} className="text-dohmi-orange" />
          <a href="mailto:contacto@dohmi.com" className="transition-colors">
            contacto@dohmi.com
          </a>
        </li>
        <li className="group flex items-center space-x-3 hover:text-dohmi-orange transition-colors">
          <Phone size={20} className="text-dohmi-orange" />
          <a href="tel:+525555555555" className="transition-colors">
            +52 (55) 5555-5555
          </a>
        </li>
        <li className="group flex items-center space-x-3">
          <MapPin size={20} className="text-dohmi-orange" />
          <span>Av. Insurgentes Sur 1234, CDMX</span>
        </li>
      </ul>
    </div>
  );
}