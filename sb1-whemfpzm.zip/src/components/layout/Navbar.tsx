import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Menu, X, Globe } from 'lucide-react';

interface NavbarProps {
  onNavigate: (page: string) => void;
  currentPage: string;
}

export default function Navbar({ onNavigate, currentPage }: NavbarProps) {
  const { t, i18n } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);

  const toggleLanguage = () => {
    i18n.changeLanguage(i18n.language === 'es' ? 'en' : 'es');
  };

  const handleNavigation = (page: string) => {
    onNavigate(page);
    setIsOpen(false);
  };

  return (
    <>
      {/* Spacer div to prevent content from being hidden under fixed navbar */}
      <div className="h-16"></div>
      
      <nav className="bg-white/95 backdrop-blur-md shadow-lg fixed top-0 left-0 right-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Main Navigation Bar */}
          <div className="flex justify-between h-16">
            {/* Logo */}
            <div className="flex items-center">
              <span
                onClick={() => handleNavigation('home')}
                className="text-2xl font-display font-bold text-dohmi-orange cursor-pointer"
              >
                DOHMI
              </span>
            </div>

            {/* Desktop Navigation Menu */}
            <div className="hidden md:flex items-center space-x-8">
              <a
                href="#"
                onClick={() => handleNavigation('home')}
                className={`${
                  currentPage === 'home'
                    ? 'text-dohmi-orange'
                    : 'text-dohmi-copper'
                } hover:text-dohmi-orange transition-colors duration-200`}
              >
                {t('nav.home')}
              </a>
              <a
                href="#"
                onClick={() => handleNavigation('buy')}
                className={`${
                  currentPage === 'buy'
                    ? 'text-dohmi-orange'
                    : 'text-dohmi-copper'
                } hover:text-dohmi-orange transition-colors duration-200`}
              >
                {t('nav.buy')}
              </a>
              <a
                href="#"
                onClick={() => handleNavigation('rent')}
                className={`${
                  currentPage === 'rent'
                    ? 'text-dohmi-orange'
                    : 'text-dohmi-copper'
                } hover:text-dohmi-orange transition-colors duration-200`}
              >
                {t('nav.rent')}
              </a>
              <a
                href="#"
                onClick={() => handleNavigation('sell')}
                className={`${
                  currentPage === 'sell'
                    ? 'text-dohmi-orange'
                    : 'text-dohmi-copper'
                } hover:text-dohmi-orange transition-colors duration-200`}
              >
                {t('nav.sell')}
              </a>
              <a
                href="#"
                onClick={() => handleNavigation('advisory')}
                className={`${
                  currentPage === 'advisory'
                    ? 'text-dohmi-orange'
                    : 'text-dohmi-copper'
                } hover:text-dohmi-orange transition-colors duration-200`}
              >
                {t('nav.advisory')}
              </a>
              <button
                onClick={toggleLanguage}
                className="flex items-center text-dohmi-copper hover:text-dohmi-orange transition-colors duration-200"
              >
                <Globe size={20} className="mr-1" />
                {i18n.language.toUpperCase()}
              </button>
            </div>

            {/* Mobile Menu Toggle */}
            <div className="md:hidden flex items-center">
              <button
                onClick={() => setIsOpen(!isOpen)}
                className="text-dohmi-copper hover:text-dohmi-orange transition-colors duration-200"
              >
                {isOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>

          {/* Mobile Navigation Menu */}
          {isOpen && (
            <div className="md:hidden bg-white/95 backdrop-blur-md border-t border-gray-200">
              <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
                <a
                  href="#"
                  onClick={() => handleNavigation('home')}
                  className={`block px-3 py-2 rounded-lg ${
                    currentPage === 'home'
                      ? 'text-dohmi-orange bg-dohmi-orange/10'
                      : 'text-dohmi-copper'
                  } hover:text-dohmi-orange hover:bg-dohmi-orange/5 transition-colors duration-200`}
                >
                  {t('nav.home')}
                </a>
                <a
                  href="#"
                  onClick={() => handleNavigation('buy')}
                  className={`block px-3 py-2 rounded-lg ${
                    currentPage === 'buy'
                      ? 'text-dohmi-orange bg-dohmi-orange/10'
                      : 'text-dohmi-copper'
                  } hover:text-dohmi-orange hover:bg-dohmi-orange/5 transition-colors duration-200`}
                >
                  {t('nav.buy')}
                </a>
                <a
                  href="#"
                  onClick={() => handleNavigation('rent')}
                  className={`block px-3 py-2 rounded-lg ${
                    currentPage === 'rent'
                      ? 'text-dohmi-orange bg-dohmi-orange/10'
                      : 'text-dohmi-copper'
                  } hover:text-dohmi-orange hover:bg-dohmi-orange/5 transition-colors duration-200`}
                >
                  {t('nav.rent')}
                </a>
                <a
                  href="#"
                  onClick={() => handleNavigation('sell')}
                  className={`block px-3 py-2 rounded-lg ${
                    currentPage === 'sell'
                      ? 'text-dohmi-orange bg-dohmi-orange/10'
                      : 'text-dohmi-copper'
                  } hover:text-dohmi-orange hover:bg-dohmi-orange/5 transition-colors duration-200`}
                >
                  {t('nav.sell')}
                </a>
                <a
                  href="#"
                  onClick={() => handleNavigation('advisory')}
                  className={`block px-3 py-2 rounded-lg ${
                    currentPage === 'advisory'
                      ? 'text-dohmi-orange bg-dohmi-orange/10'
                      : 'text-dohmi-copper'
                  } hover:text-dohmi-orange hover:bg-dohmi-orange/5 transition-colors duration-200`}
                >
                  {t('nav.advisory')}
                </a>
                <button
                  onClick={toggleLanguage}
                  className="flex items-center px-3 py-2 w-full rounded-lg text-dohmi-copper hover:text-dohmi-orange hover:bg-dohmi-orange/5 transition-colors duration-200"
                >
                  <Globe size={20} className="mr-1" />
                  {i18n.language.toUpperCase()}
                </button>
              </div>
            </div>
          )}
        </div>
      </nav>
    </>
  );
}