import React from 'react';
import { useTranslation } from 'react-i18next';
import { ArrowRight } from 'lucide-react';

export default function NewsletterForm() {
  const { t } = useTranslation();

  return (
    <div className="space-y-6">
      <h4 className="font-display text-2xl text-dohmi-orange">
        {t('footer.newsletter.title')}
      </h4>
      <p className="text-sm">{t('footer.newsletter.description')}</p>
      <form className="space-y-3">
        <input
          type="email"
          placeholder={t('footer.newsletter.placeholder')}
          className="w-full px-4 py-3 rounded-xl bg-white/10 border border-dohmi-orange/30 focus:border-dohmi-orange focus:outline-none focus:ring-2 focus:ring-dohmi-orange/50 placeholder-dohmi-cream/70"
        />
        <button
          type="submit"
          className="w-full bg-dohmi-orange hover:bg-dohmi-yellow text-white px-6 py-3 rounded-xl transition duration-300 transform hover:scale-105 flex items-center justify-center group"
        >
          <span>{t('footer.newsletter.button')}</span>
          <ArrowRight
            size={20}
            className="ml-2 transform transition-transform group-hover:translate-x-2"
          />
        </button>
      </form>
    </div>
  );
}
