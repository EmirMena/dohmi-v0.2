import React from 'react';
import { useTranslation } from 'react-i18next';
import { ArrowRight } from 'lucide-react';

export default function QuickLinks() {
  const { t } = useTranslation();

  const links = [
    { key: 'featured', href: '#' },
    { key: 'advisory', href: '#' },
    { key: 'terms', href: '#' },
    { key: 'privacy', href: '#' },
  ];

  return (
    <div className="space-y-6">
      <h4 className="font-display text-2xl text-dohmi-orange">
        {t('footer.quickLinks.label')}
      </h4>
      <ul className="space-y-3">
        {links.map((link) => (
          <li key={link.key}>
            <a
              href={link.href}
              className="group flex items-center space-x-2 hover:text-dohmi-orange transition-colors"
            >
              <ArrowRight
                size={16}
                className="transform transition-transform group-hover:translate-x-2"
              />
              <span>{t(`footer.quickLinks.${link.key}`)}</span>
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
}
