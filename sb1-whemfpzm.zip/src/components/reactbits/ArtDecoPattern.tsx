import React, { useRef, useEffect } from 'react';

type CanvasStrokeStyle = string | CanvasGradient | CanvasPattern;

interface GridOffset {
  x: number;
  y: number;
}

interface ArtDecoPatternProps {
  direction?: 'diagonal' | 'up' | 'right' | 'down' | 'left';
  speed?: number;
  primaryColor?: CanvasStrokeStyle;
  secondaryColor?: CanvasStrokeStyle;
  patternSize?: number;
  hoverFillColor?: CanvasStrokeStyle;
}

const ArtDecoPattern: React.FC<ArtDecoPatternProps> = ({
  direction = 'right',
  speed = 1,
  primaryColor = '#999',
  secondaryColor = '#666',
  patternSize = 150,
  hoverFillColor = 'rgba(255, 215, 0, 0.3)', // Dorado con transparencia
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestRef = useRef<number | null>(null);
  const numPatternsX = useRef<number>(0);
  const numPatternsY = useRef<number>(0);
  const gridOffset = useRef<GridOffset>({ x: 0, y: 0 });
  const hoveredPatternRef = useRef<GridOffset | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    const resizeCanvas = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
      numPatternsX.current = Math.ceil(canvas.width / patternSize) + 1;
      numPatternsY.current = Math.ceil(canvas.height / patternSize) + 1;
    };

    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();

    const drawPattern = () => {
      if (!ctx) return;

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const startX =
        Math.floor(gridOffset.current.x / patternSize) * patternSize;
      const startY =
        Math.floor(gridOffset.current.y / patternSize) * patternSize;

      for (let x = startX; x < canvas.width + patternSize; x += patternSize) {
        for (
          let y = startY;
          y < canvas.height + patternSize;
          y += patternSize
        ) {
          const patternX = x - (gridOffset.current.x % patternSize);
          const patternY = y - (gridOffset.current.y % patternSize);

          // **Formas Art Decó**
          ctx.strokeStyle = primaryColor;
          ctx.fillStyle = secondaryColor;
          ctx.lineWidth = 2;

          // 1. Triángulo escalonado (forma típica del Art Decó)
          ctx.beginPath();
          ctx.moveTo(patternX, patternY + patternSize);
          ctx.lineTo(patternX + patternSize / 2, patternY);
          ctx.lineTo(patternX + patternSize, patternY + patternSize);
          ctx.closePath();
          ctx.stroke();

          // 2. Círculos concéntricos
          ctx.beginPath();
          ctx.arc(
            patternX + patternSize / 2,
            patternY + patternSize / 2,
            patternSize / 4,
            0,
            Math.PI * 2
          );
          ctx.stroke();

          ctx.beginPath();
          ctx.arc(
            patternX + patternSize / 2,
            patternY + patternSize / 2,
            patternSize / 8,
            0,
            Math.PI * 2
          );
          ctx.fill();

          // 3. Líneas diagonales decorativas
          ctx.beginPath();
          ctx.moveTo(patternX, patternY);
          ctx.lineTo(patternX + patternSize, patternY + patternSize);
          ctx.stroke();

          ctx.beginPath();
          ctx.moveTo(patternX + patternSize, patternY);
          ctx.lineTo(patternX, patternY + patternSize);
          ctx.stroke();

          // Efecto hover
          if (
            hoveredPatternRef.current &&
            Math.floor((x - startX) / patternSize) ===
              hoveredPatternRef.current.x &&
            Math.floor((y - startY) / patternSize) ===
              hoveredPatternRef.current.y
          ) {
            ctx.fillStyle = hoverFillColor;
            ctx.fillRect(patternX, patternY, patternSize, patternSize);
          }
        }
      }

      // Gradiente para suavizar los bordes
      const gradient = ctx.createRadialGradient(
        canvas.width / 2,
        canvas.height / 2,
        0,
        canvas.width / 2,
        canvas.height / 2,
        Math.sqrt(canvas.width ** 2 + canvas.height ** 2) / 2
      );
      gradient.addColorStop(0.5, 'rgba(255, 243, 229, 0)');
      gradient.addColorStop(1, 'rgba(0,0,0,0.4)');

      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    };

    const updateAnimation = () => {
      const effectiveSpeed = Math.max(speed, 0.1);
      switch (direction) {
        case 'right':
          gridOffset.current.x =
            (gridOffset.current.x - effectiveSpeed + patternSize) % patternSize;
          break;
        case 'left':
          gridOffset.current.x =
            (gridOffset.current.x + effectiveSpeed + patternSize) % patternSize;
          break;
        case 'up':
          gridOffset.current.y =
            (gridOffset.current.y + effectiveSpeed + patternSize) % patternSize;
          break;
        case 'down':
          gridOffset.current.y =
            (gridOffset.current.y - effectiveSpeed + patternSize) % patternSize;
          break;
        case 'diagonal':
          gridOffset.current.x =
            (gridOffset.current.x - effectiveSpeed + patternSize) % patternSize;
          gridOffset.current.y =
            (gridOffset.current.y - effectiveSpeed + patternSize) % patternSize;
          break;
        default:
          break;
      }

      drawPattern();
      requestRef.current = requestAnimationFrame(updateAnimation);
    };

    const handleMouseMove = (event: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      const mouseX = event.clientX - rect.left;
      const mouseY = event.clientY - rect.top;

      const startX =
        Math.floor(gridOffset.current.x / patternSize) * patternSize;
      const startY =
        Math.floor(gridOffset.current.y / patternSize) * patternSize;

      const hoveredPatternX = Math.floor(
        (mouseX + gridOffset.current.x - startX) / patternSize
      );
      const hoveredPatternY = Math.floor(
        (mouseY + gridOffset.current.y - startY) / patternSize
      );

      if (
        !hoveredPatternRef.current ||
        hoveredPatternRef.current.x !== hoveredPatternX ||
        hoveredPatternRef.current.y !== hoveredPatternY
      ) {
        hoveredPatternRef.current = { x: hoveredPatternX, y: hoveredPatternY };
      }
    };

    const handleMouseLeave = () => {
      hoveredPatternRef.current = null;
    };

    canvas.addEventListener('mousemove', handleMouseMove);
    canvas.addEventListener('mouseleave', handleMouseLeave);
    requestRef.current = requestAnimationFrame(updateAnimation);

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
      canvas.removeEventListener('mousemove', handleMouseMove);
      canvas.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, [
    direction,
    speed,
    primaryColor,
    secondaryColor,
    hoverFillColor,
    patternSize,
  ]);

  return (
    <canvas
      ref={canvasRef}
      className="w-full h-full border-none block"
    ></canvas>
  );
};

export default ArtDecoPattern;
