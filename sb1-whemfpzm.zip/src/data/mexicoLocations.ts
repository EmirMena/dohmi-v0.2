interface City {
  name: string;
}

interface State {
  name: string;
  cities: City[];
}

export const mexicoStates: State[] = [
  {
    name: "Aguascalientes",
    cities: [
      { name: "Aguascalientes" },
      { name: "Jesús María" },
      { name: "Calvillo" },
      { name: "Rincón de Romos" },
      { name: "Pabellón de Arteaga" }
    ]
  },
  {
    name: "Baja California",
    cities: [
      { name: "Mexicali" },
      { name: "Tijuana" },
      { name: "Ensenada" },
      { name: "Tecate" },
      { name: "Rosarito" }
    ]
  },
  {
    name: "Baja California Sur",
    cities: [
      { name: "La Paz" },
      { name: "Los Cabos" },
      { name: "San José del Cabo" },
      { name: "Cabo San Lucas" },
      { name: "Loreto" }
    ]
  },
  {
    name: "Campeche",
    cities: [
      { name: "Campeche" },
      { name: "Ciudad del Carmen" },
      { name: "Champotón" },
      { name: "Calkiní" },
      { name: "Escárcega" }
    ]
  },
  {
    name: "Chiapas",
    cities: [
      { name: "Tuxtla Gutiérrez" },
      { name: "San Cristóbal de las Casas" },
      { name: "Tapachula" },
      { name: "Comitán" },
      { name: "Palenque" }
    ]
  },
  {
    name: "Chihuahua",
    cities: [
      { name: "Chihuahua" },
      { name: "Ciudad Juárez" },
      { name: "Delicias" },
      { name: "Cuauhtémoc" },
      { name: "Parral" }
    ]
  },
  {
    name: "Ciudad de México",
    cities: [
      { name: "Coyoacán" },
      { name: "Cuauhtémoc" },
      { name: "Iztapalapa" },
      { name: "Benito Juárez" },
      { name: "Miguel Hidalgo" }
    ]
  },
  {
    name: "Coahuila",
    cities: [
      { name: "Saltillo" },
      { name: "Torreón" },
      { name: "Monclova" },
      { name: "Piedras Negras" },
      { name: "Acuña" }
    ]
  },
  {
    name: "Colima",
    cities: [
      { name: "Colima" },
      { name: "Manzanillo" },
      { name: "Tecomán" },
      { name: "Villa de Álvarez" },
      { name: "Armería" }
    ]
  },
  {
    name: "Durango",
    cities: [
      { name: "Durango" },
      { name: "Gómez Palacio" },
      { name: "Lerdo" },
      { name: "Ciudad Lerdo" },
      { name: "Mapimí" }
    ]
  },
  {
    name: "Guanajuato",
    cities: [
      { name: "León" },
      { name: "Irapuato" },
      { name: "Celaya" },
      { name: "Guanajuato" },
      { name: "Salamanca" }
    ]
  },
  {
    name: "Guerrero",
    cities: [
      { name: "Acapulco" },
      { name: "Chilpancingo" },
      { name: "Iguala" },
      { name: "Zihuatanejo" },
      { name: "Taxco" }
    ]
  },
  {
    name: "Hidalgo",
    cities: [
      { name: "Pachuca" },
      { name: "Tulancingo" },
      { name: "Tula" },
      { name: "Ixmiquilpan" },
      { name: "Actopan" }
    ]
  },
  {
    name: "Jalisco",
    cities: [
      { name: "Guadalajara" },
      { name: "Zapopan" },
      { name: "Tlaquepaque" },
      { name: "Puerto Vallarta" },
      { name: "Tonalá" }
    ]
  },
  {
    name: "Estado de México",
    cities: [
      { name: "Toluca" },
      { name: "Ecatepec" },
      { name: "Naucalpan" },
      { name: "Tlalnepantla" },
      { name: "Nezahualcóyotl" }
    ]
  },
  {
    name: "Michoacán",
    cities: [
      { name: "Morelia" },
      { name: "Uruapan" },
      { name: "Zamora" },
      { name: "Lázaro Cárdenas" },
      { name: "Pátzcuaro" }
    ]
  },
  {
    name: "Morelos",
    cities: [
      { name: "Cuernavaca" },
      { name: "Jiutepec" },
      { name: "Temixco" },
      { name: "Cuautla" },
      { name: "Yautepec" }
    ]
  },
  {
    name: "Nayarit",
    cities: [
      { name: "Tepic" },
      { name: "Bahía de Banderas" },
      { name: "Xalisco" },
      { name: "Santiago Ixcuintla" },
      { name: "Acaponeta" }
    ]
  },
  {
    name: "Nuevo León",
    cities: [
      { name: "Monterrey" },
      { name: "San Nicolás" },
      { name: "Guadalupe" },
      { name: "Apodaca" },
      { name: "Santa Catarina" }
    ]
  },
  {
    name: "Oaxaca",
    cities: [
      { name: "Oaxaca de Juárez" },
      { name: "Salina Cruz" },
      { name: "Juchitán" },
      { name: "Tehuantepec" },
      { name: "Huajuapan de León" }
    ]
  },
  {
    name: "Puebla",
    cities: [
      { name: "Puebla" },
      { name: "Tehuacán" },
      { name: "Atlixco" },
      { name: "San Martín Texmelucan" },
      { name: "Cholula" }
    ]
  },
  {
    name: "Querétaro",
    cities: [
      { name: "Querétaro" },
      { name: "San Juan del Río" },
      { name: "El Marqués" },
      { name: "Corregidora" },
      { name: "Jalpan de Serra" }
    ]
  },
  {
    name: "Quintana Roo",
    cities: [
      { name: "Cancún" },
      { name: "Playa del Carmen" },
      { name: "Chetumal" },
      { name: "Tulum" },
      { name: "Cozumel" }
    ]
  },
  {
    name: "San Luis Potosí",
    cities: [
      { name: "San Luis Potosí" },
      { name: "Soledad de Graciano Sánchez" },
      { name: "Matehuala" },
      { name: "Ciudad Valles" },
      { name: "Rioverde" }
    ]
  },
  {
    name: "Sinaloa",
    cities: [
      { name: "Culiacán" },
      { name: "Mazatlán" },
      { name: "Los Mochis" },
      { name: "Guamúchil" },
      { name: "El Fuerte" }
    ]
  },
  {
    name: "Sonora",
    cities: [
      { name: "Hermosillo" },
      { name: "Ciudad Obregón" },
      { name: "Nogales" },
      { name: "San Luis Río Colorado" },
      { name: "Navojoa" }
    ]
  },
  {
    name: "Tabasco",
    cities: [
      { name: "Villahermosa" },
      { name: "Cárdenas" },
      { name: "Comalcalco" },
      { name: "Paraíso" },
      { name: "Balancán" }
    ]
  },
  {
    name: "Tamaulipas",
    cities: [
      { name: "Ciudad Victoria" },
      { name: "Matamoros" },
      { name: "Reynosa" },
      { name: "Nuevo Laredo" },
      { name: "Tampico" }
    ]
  },
  {
    name: "Tlaxcala",
    cities: [
      { name: "Tlaxcala" },
      { name: "Apizaco" },
      { name: "Huamantla" },
      { name: "Chiautempan" },
      { name: "Tetla de la Solidaridad" }
    ]
  },
  {
    name: "Veracruz",
    cities: [
      { name: "Veracruz" },
      { name: "Xalapa" },
      { name: "Coatzacoalcos" },
      { name: "Poza Rica" },
      { name: "Orizaba" }
    ]
  },
  {
    name: "Yucatán",
    cities: [
      { name: "Mérida" },
      { name: "Valladolid" },
      { name: "Progreso" },
      { name: "Motul" },
      { name: "Tizimín" }
    ]
  },
  {
    name: "Zacatecas",
    cities: [
      { name: "Zacatecas" },
      { name: "Fresnillo" },
      { name: "Guadalupe" },
      { name: "Jerez" },
      { name: "Sombrerete" }
    ]
  }
];
