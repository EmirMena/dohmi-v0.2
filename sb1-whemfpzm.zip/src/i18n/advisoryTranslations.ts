// Definición de los recursos de traducción para inglés y español
const advisoryTranslations = {
  en: {
    hero: {
      title: 'Other Section Title',
      description: 'Description of the other section',
      // ...otros textos para esta sección
    },
  },
  es: {
    hero: {
      title: 'Título de Otra Sección',
      description: 'Descripción de la otra sección',
      // ...otros textos para esta sección
    },
  },
};

export default advisoryTranslations;
