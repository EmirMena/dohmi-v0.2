const homeTranslations = {
  en: {
    home: {
      nav: {
        home: 'Home',
        buy: 'Buy',
        // ...otros textos
      },
      hero: {
        title: 'Find Your Dream Home',
        subtitle: 'Your trusted partner in real estate',
      },
      // ...más secciones de la home
    },
  },
  es: {
    home: {
      nav: {
        home: 'Inicio',
        buy: 'Comprar',
        // ...otros textos
      },
      hero: {
        title: 'Encuentra Tu Hogar Ideal',
        subtitle: 'Tu socio de confianza en bienes raíces',
      },
      // ...más secciones de la home
    },
  },
};

export default homeTranslations;
