// Importa los módulos necesarios
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

// Definición de los recursos de traducción para inglés y español
const resources = {
  en: {
    translation: {
      nav: {
        home: 'Home',
        buy: 'Buy',
        rent: 'Rent',
        sell: 'Sell',
        contact: 'Contact',
        advisory: 'Advisory',
      },
      hero: {
        title: 'Find Your Dream Home',
        subtitle: 'Your trusted partner in real estate',
      },
      Questionnaire: {
        navigation: {
          back: 'Previous Question',
        },
        purpose: {
          question: 'What is the main purpose of your search?',
          family: 'Live with my family',
          investment: 'Investment',
          vacation: 'Vacation',
          student: "I'm a student",
        },
        intention: {
          question: 'Are you looking to buy or rent?',
          buy: 'Buy a property',
          rent: 'Rent a property',
        },
        timeframe: {
          question: 'When do you plan to move?',
          immediate: 'As soon as possible',
          short: 'Next 3-6 months',
          medium: 'Within 6-12 months',
          planning: 'Future planning',
        },
        lifestyle: {
          question: 'What type of environment are you looking for?',
          school: 'Near schools and parks',
          suburban: 'Quiet residential area',
          gated: 'Gated community with amenities',
          nature: 'Close to natural areas',
        },
        budget: {
          question: 'What is your budget?',
          starter_buy: '$2,000,000 - $3,500,000',
          mid_buy: '$3,500,000 - $5,000,000',
          high_buy: '$5,000,000 - $8,000,000',
          luxury_buy: 'Over $8,000,000',
          starter_rent: '$15,000 - $25,000 monthly',
          mid_rent: '$25,000 - $40,000 monthly',
          high_rent: '$40,000 - $60,000 monthly',
          luxury_rent: 'Over $60,000 monthly',
        },
        contact: {
          title: 'How can we contact you?',
          description:
            'Enter your WhatsApp number and we will send you personalized recommendations.',
          placeholder: 'Your WhatsApp number',
          button: 'Get Recommendations',
        },
        investment: {
          timeframe: {
            question: 'What is your investment horizon?',
            short: 'Short term (1-2 years)',
            medium: 'Medium term (3-5 years)',
            long: 'Long term (5+ years)',
            flip: 'Quick purchase and renovation',
          },
          type: {
            question: 'What type of property interests you for investment?',
            residential: 'Residential for rent',
            commercial: 'Commercial',
            mixed: 'Mixed use',
            land: 'Land',
          },
          budget: {
            question: 'What is your investment capital?',
            small: 'Up to $5,000,000',
            medium: '$5,000,000 - $10,000,000',
            large: '$10,000,000 - $20,000,000',
            institutional: 'Over $20,000,000',
          },
        },
        vacation: {
          frequency: {
            question: 'How often do you plan to use the property?',
            weekends: 'Weekends',
            seasonal: 'Vacation seasons',
            occasional: 'Occasionally',
            rental: 'For vacation rental',
          },
          location: {
            question: 'What type of destination do you prefer?',
            beach: 'Beach',
            mountain: 'Mountain',
            colonial: 'Colonial city',
            resort: 'Tourist area',
          },
          budget: {
            question: 'What is your vacation home budget?',
            modest: '$1,500,000 - $3,000,000',
            comfort: '$3,000,000 - $5,000,000',
            luxury: '$5,000,000 - $10,000,000',
            elite: 'Over $10,000,000',
          },
        },
        student: {
          timeframe: {
            question: 'When do you need the property?',
            immediate: 'For this semester',
            next: 'Next semester',
            planning: 'Planning ahead',
            flexible: 'Flexible dates',
          },
          type: {
            question: 'What type of accommodation are you looking for?',
            studio: 'Individual studio',
            shared: 'Shared apartment',
            residence: 'Student residence',
            house: 'Student house',
          },
          budget: {
            question: 'What is your monthly budget?',
            basic: '$5,000 - $8,000',
            standard: '$8,000 - $12,000',
            comfort: '$12,000 - $15,000',
            premium: 'Over $15,000',
          },
        },
        thanks: {
          title: 'Thank you for sharing your preferences!',
          text: 'Our team of experts will analyze your responses and contact you soon with a personalized selection of properties that perfectly suit your needs.',
          button: 'Start again',
        },
      },
      services: {
        title: 'Our Services',
        advisory: {
          title: 'Personalized Advisory',
          description: 'Expert guidance throughout your real estate journey',
        },
        properties: {
          title: 'Buy & Rent Properties',
          description: 'Discover your perfect space',
        },
        sell: {
          title: 'Sell Properties',
          description: 'List your property with confidence',
        },
      },
      cta: {
        consult: 'Request Consultation',
        explore: 'Explore Properties',
        publish: 'List Your Property',
      },
      footer: {
        hours: {
          label: 'Business Hours',
          weekdays: 'Monday to Friday: 9:00 - 18:00',
          saturday: 'Saturday: 10:00 - 14:00',
        },
        quickLinks: {
          label: 'Quick Links',
          featured: 'Featured Properties',
          advisory: 'Advisory Services',
          terms: 'Terms & Conditions',
          privacy: 'Privacy Policy',
        },
        newsletter: {
          title: 'Newsletter',
          description: 'Receive the latest news and exclusive offers.',
          placeholder: 'Your email',
          button: 'Subscribe',
        },
        copyright: '©{{year}} DOHMI. All rights reserved.',
      },
    },
  },
  es: {
    translation: {
      nav: {
        home: 'Inicio',
        buy: 'Comprar',
        rent: 'Alquilar',
        sell: 'Vender',
        contact: 'Contacto',
        advisory: 'Asesoría',
      },
      hero: {
        title: 'Encuentra Tu Hogar Ideal',
        subtitle: 'Tu socio de confianza en bienes raíces',
      },
      Questionnaire: {
        navigation: {
          back: 'Pregunta Anterior',
        },
        purpose: {
          question: '¿Cuál es el propósito principal de su búsqueda?',
          family: 'Vivir con mi familia',
          investment: 'Invertir',
          vacation: 'Vacaciones',
          student: 'Soy estudiante',
        },
        intention: {
          question: '¿Está buscando comprar o rentar?',
          buy: 'Comprar una propiedad',
          rent: 'Rentar una propiedad',
        },
        timeframe: {
          question: '¿En qué plazo planea mudarse?',
          immediate: 'Lo antes posible',
          short: 'En los próximos 3-6 meses',
          medium: 'Dentro de 6-12 meses',
          planning: 'Estamos planificando a futuro',
        },
        lifestyle: {
          question: '¿Qué tipo de entorno busca?',
          school: 'Cerca de escuelas y parques',
          suburban: 'Zona residencial tranquila',
          gated: 'Comunidad cerrada con amenidades',
          nature: 'Cerca de áreas naturales',
        },
        budget: {
          question: '¿Cuál es su presupuesto?',
          starter_buy: '$2,000,000 - $3,500,000',
          mid_buy: '$3,500,000 - $5,000,000',
          high_buy: '$5,000,000 - $8,000,000',
          luxury_buy: 'Más de $8,000,000',
          starter_rent: '$15,000 - $25,000 mensuales',
          mid_rent: '$25,000 - $40,000 mensuales',
          high_rent: '$40,000 - $60,000 mensuales',
          luxury_rent: 'Más de $60,000 mensuales',
        },
        contact: {
          title: '¿Cómo podemos contactarte?',
          description:
            'Ingresa tu número de WhatsApp y te enviaremos recomendaciones personalizadas.',
          placeholder: 'Tu número de WhatsApp',
          button: 'Obtener Recomendaciones',
        },
        investment: {
          timeframe: {
            question: '¿Cuál es su horizonte de inversión?',
            short: 'Corto plazo (1-2 años)',
            medium: 'Mediano plazo (3-5 años)',
            long: 'Largo plazo (5+ años)',
            flip: 'Compra y renovación rápida',
          },
          type: {
            question: '¿Qué tipo de propiedad le interesa para invertir?',
            residential: 'Residencial para renta',
            commercial: 'Comercial',
            mixed: 'Uso mixto',
            land: 'Terrenos',
          },
          budget: {
            question: '¿Cuál es su capital de inversión?',
            small: 'Hasta $5,000,000',
            medium: '$5,000,000 - $10,000,000',
            large: '$10,000,000 - $20,000,000',
            institutional: 'Más de $20,000,000',
          },
        },
        vacation: {
          frequency: {
            question: '¿Con qué frecuencia planea usar la propiedad?',
            weekends: 'Fines de semana',
            seasonal: 'Temporadas vacacionales',
            occasional: 'Ocasionalmente',
            rental: 'Para renta vacacional',
          },
          location: {
            question: '¿Qué tipo de destino prefiere?',
            beach: 'Playa',
            mountain: 'Montaña',
            colonial: 'Ciudad colonial',
            resort: 'Zona turística',
          },
          budget: {
            question: '¿Cuál es su presupuesto para casa vacacional?',
            modest: '$1,500,000 - $3,000,000',
            comfort: '$3,000,000 - $5,000,000',
            luxury: '$5,000,000 - $10,000,000',
            elite: 'Más de $10,000,000',
          },
        },
        student: {
          timeframe: {
            question: '¿Cuándo necesitas la propiedad?',
            immediate: 'Para este semestre',
            next: 'Próximo semestre',
            planning: 'Planeando con anticipación',
            flexible: 'Fechas flexibles',
          },
          type: {
            question: '¿Qué tipo de alojamiento buscas?',
            studio: 'Estudio individual',
            shared: 'Departamento compartido',
            residence: 'Residencia estudiantil',
            house: 'Casa para estudiantes',
          },
          budget: {
            question: '¿Cuál es tu presupuesto mensual?',
            basic: '$5,000 - $8,000',

            standard: '$8,000 - $12,000',
            comfort: '$12,000 - $15,000',
            premium: 'Más de $15,000',
          },
        },
        thanks: {
          title: '¡Gracias por compartir sus preferencias!',
          text: 'Nuestro equipo de expertos analizará sus respuestas y le contactará pronto con una selección personalizada de propiedades que se ajusten perfectamente a sus necesidades.',
          button: 'Comenzar de nuevo',
        },
      },
      services: {
        title: 'Nuestros servicios',
        advisory: {
          title: 'Asesoría Personalizada',
          description: 'Guía experta durante tu proceso inmobiliario',
        },
        properties: {
          title: 'Compra y Alquiler',
          description: 'Descubre tu espacio perfecto',
        },
        sell: {
          title: 'Venta de Propiedades',
          description: 'Publica tu propiedad con confianza',
        },
      },
      cta: {
        consult: 'Solicitar Asesoría',
        explore: 'Explorar Propiedades',
        publish: 'Publicar Inmueble',
      },
      footer: {
        hours: {
          label: 'Horario de Atención',
          weekdays: 'Lunes a Viernes: 9:00 - 18:00',
          saturday: 'Sábados: 10:00 - 14:00',
        },
        quickLinks: {
          label: 'Enlaces Rápidos',
          featured: 'Propiedades Destacadas',
          advisory: 'Servicios de Asesoría',
          terms: 'Términos y Condiciones',
          privacy: 'Política de Privacidad',
        },
        newsletter: {
          title: 'Noticias',
          description: 'Recibe las últimas novedades y ofertas exclusivas.',
          placeholder: 'Tu correo electrónico',
          button: 'Suscribirse',
        },
        copyright: '© {{year}} DOHMI. Todos los derechos reservados.',
      },
    },
  },
};

i18n.use(initReactI18next).init({
  resources,
  lng: 'es',
  interpolation: {
    escapeValue: false,
  },
});

export default i18n;
