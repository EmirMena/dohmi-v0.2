import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

interface SaveQuestionnaireResponse {
  respuesta_id?: string;
  proposito: string;
  intencion_id?: string;
  plazo_id: string;
  estilo_vida: string;
  presupuesto: string;
  usuario_id?: string | null;
}

export interface AdvisoryRequest {
  name: string;
  position: string;
  company: string;
  city: string;
  state: string;
  phone: string;
  country_code: string;
}

export async function saveAdvisoryRequest(data: AdvisoryRequest): Promise<void> {
  const { error } = await supabase
    .from('respuestas_cuestionario')
    .insert([data]);

  if (error) {
    console.error('Error saving advisory request:', error);
    throw error;
  }
}

export async function guardarRespuestaCuestionario(answers: Record<number, string>): Promise<void> {
  try {
    // Generar un UUID para respuesta_id
    const respuesta_id = crypto.randomUUID();

    // Mapear las respuestas a los IDs correspondientes
    const respuesta: SaveQuestionnaireResponse = {
      respuesta_id,
      proposito: getPropositoId(answers[1]),
      plazo_id: getPlazoId(answers[2]),
      estilo_vida: getEstiloVidaId(answers[3]),
      presupuesto: answers[4] || '',
      usuario_id: null // Como no hay sistema de autenticación aún, lo dejamos como null
    };

    // Si es familia, incluir intención
    if (answers[1] === 'family') {
      respuesta.intencion_id = getIntencionId(answers[2]);
      // Ajustar el orden de los campos para familia
      respuesta.plazo_id = getPlazoId(answers[3]);
      respuesta.estilo_vida = getEstiloVidaId(answers[4]);
      respuesta.presupuesto = answers[5] || '';
    }

    const { error } = await supabase
      .from('respuestas_cuestionario')
      .insert([respuesta]);

    if (error) {
      throw error;
    }
  } catch (error) {
    console.error('Error al guardar la respuesta:', error);
    throw error;
  }
}

// Funciones auxiliares para mapear respuestas a IDs
function getPropositoId(proposito: string): string {
  const propositos: Record<string, string> = {
    'family': '2892c593-de5c-41ed-9e68-c39a55979a7b',     // Familiar
    'investment': 'aefcd42b-5d2c-4455-974c-9bdd6a5cfea6',  // Inversión
    'vacation': '9e370197-56b0-47e3-a30d-d74bd7c64ec6',    // Vacaciones
    'student': '815504a8-2282-4320-b481-735cd8628033'      // Estudiante
  };
  return propositos[proposito] || '2892c593-de5c-41ed-9e68-c39a55979a7b'; // Default to Familiar
}

function getIntencionId(intencion: string): string {
  const intenciones: Record<string, string> = {
    'buy': '1ccc1ec3-7fdb-4f2c-8423-2346b6a13850',   // Compra
    'rent': 'cda6f3a7-2be9-4473-b7e6-aec31cfeecb5'   // Renta
  };
  return intenciones[intencion] || '1ccc1ec3-7fdb-4f2c-8423-2346b6a13850'; // Default to Compra
}

function getPlazoId(plazo: string): string {
  const plazos: Record<string, string> = {
    'immediate': '5aa36812-5ea6-4ff6-abbf-a196721fa822',    // Inmediato
    'short': '68b5012d-a18e-4603-a2cb-cada51934ace',       // Corto plazo
    'medium': 'c21be765-4bc3-4581-aace-ad6c4df87725',      // Mediano plazo
    'planning': '2275b6d9-24b4-43ef-99bf-0dbf0114b15c',    // Largo plazo
    'flexible': '90b8765d-fa79-4d78-b9fe-b0ea69b45d6c'     // Flexible
  };
  return plazos[plazo] || '5aa36812-5ea6-4ff6-abbf-a196721fa822'; // Default to Inmediato
}

function getEstiloVidaId(estiloVida: string): string {
  const estilosVida: Record<string, string> = {
    'school': 'dd9942dd-9c89-4528-9089-cb86c726b62b',      // Escolar
    'suburban': '7f16c7cb-f985-4fcb-a8a9-5bb4355adfb0',    // Suburbano
    'gated': '4dab9614-2bda-49b9-b568-f4cc4476f0e1',       // Privado
    'nature': '3e43066e-890a-40b5-b13a-66c89e58d41f',      // Naturaleza
    'residential': 'e281511e-a388-495d-97c7-7e398058f417', // Residencial
    'commercial': 'badb7d3c-5497-434f-aee8-93d1b40935a1',  // Comercial
    'mixed': '4a2e2481-99df-4089-8e81-1e2844429545'        // Mixto
  };
  return estilosVida[estiloVida] || 'dd9942dd-9c89-4528-9089-cb86c726b62b'; // Default to Escolar
}