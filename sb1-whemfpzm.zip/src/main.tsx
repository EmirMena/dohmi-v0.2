import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// 👇 IMPORTA el cliente de Supabase
import { supabase } from './lib/supabase'; // Ajusta la ruta según tu estructura

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>
);

// Función de prueba para verificar la conexión
async function testConnection() {
  const { data, error } = await supabase
    .from('respuestas_cuestionario') // Usa cualquier tabla existente
    .select('*')
    .limit(1);

  if (error) {
    console.error('❌ Error al conectar con Supabase:', error);
  } else {
    console.log('✅ Conexión exitosa con Supabase. Primer resultado:', data);
  }
}

testConnection();