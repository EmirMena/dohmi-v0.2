/*
  # Create questionnaire response tables

  1. New Tables
    - `respuestas_cuestionario`
      - `respuesta_id` (uuid, primary key)
      - `proposito` (uuid, references propositos)
      - `intencion` (uuid, references intenciones, nullable)
      - `plazo` (uuid, references plazos)
      - `estilo_vida` (uuid, references estilos_vida)
      - `presupuesto` (text)
      - `usuario_id` (uuid, references auth.users, nullable)
      - `created_at` (timestamptz)

    - `propositos` (lookup table)
      - `id` (uuid, primary key)
      - `nombre` (text)
      - `descripcion` (text)

    - `intenciones` (lookup table)
      - `id` (uuid, primary key)
      - `nombre` (text)
      - `descripcion` (text)

    - `plazos` (lookup table)
      - `id` (uuid, primary key)
      - `nombre` (text)
      - `descripcion` (text)

    - `estilos_vida` (lookup table)
      - `id` (uuid, primary key)
      - `nombre` (text)
      - `descripcion` (text)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to read their own data
    - Add policies for anon users to insert responses

CREATE TABLE IF NOT EXISTS propositos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre text NOT NULL,
  descripcion text,
  created_at timestamptz DEFAULT now()
);

-- Crear tabla de intenciones
CREATE TABLE IF NOT EXISTS intenciones (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre text NOT NULL,
  descripcion text,
  created_at timestamptz DEFAULT now()
);

-- Crear tabla de plazos
CREATE TABLE IF NOT EXISTS plazos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre text NOT NULL,
  descripcion text,
  created_at timestamptz DEFAULT now()
);

-- Crear tabla de estilos de vida
CREATE TABLE IF NOT EXISTS estilos_vida (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre text NOT NULL,
  descripcion text,
  created_at timestamptz DEFAULT now()
);

-- Crear tabla principal de respuestas
CREATE TABLE IF NOT EXISTS respuestas_cuestionario (
  respuesta_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  proposito uuid REFERENCES propositos(id),
  intencion uuid REFERENCES intenciones(id),
  plazo uuid REFERENCES plazos(id),
  estilo_vida uuid REFERENCES estilos_vida(id),
  presupuesto text,
  usuario_id uuid REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now()
);

-- Habilitar RLS en todas las tablas
ALTER TABLE propositos ENABLE ROW LEVEL SECURITY;
ALTER TABLE intenciones ENABLE ROW LEVEL SECURITY;
ALTER TABLE plazos ENABLE ROW LEVEL SECURITY;
ALTER TABLE estilos_vida ENABLE ROW LEVEL SECURITY;
ALTER TABLE respuestas_cuestionario ENABLE ROW LEVEL SECURITY;

-- Políticas para tablas de catálogo (solo lectura para todos)
CREATE POLICY "Permitir lectura de propósitos a todos"
  ON propositos FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Permitir lectura de intenciones a todos"
  ON intenciones FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Permitir lectura de plazos a todos"
  ON plazos FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Permitir lectura de estilos de vida a todos"
  ON estilos_vida FOR SELECT
  TO public
  USING (true);

-- Políticas para respuestas del cuestionario
CREATE POLICY "Permitir inserción de respuestas a anónimos"
  ON respuestas_cuestionario FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Usuarios pueden leer sus propias respuestas"
  ON respuestas_cuestionario FOR SELECT
  TO authenticated
  USING (auth.uid() = usuario_id);

-- Insertar datos de catálogo
INSERT INTO propositos (id, nombre, descripcion) VALUES
  ('2892c593-de5c-41ed-9e68-c39a55979a7b', 'Familiar', 'Búsqueda para vivir con la familia'),
  ('aefcd42b-5d2c-4455-974c-9bdd6a5cfea6', 'Inversión', 'Búsqueda con fines de inversión'),
  ('9e370197-56b0-47e3-a30d-d74bd7c64ec6', 'Vacaciones', 'Búsqueda de propiedad vacacional'),
  ('815504a8-2282-4320-b481-735cd8628033', 'Estudiante', 'Búsqueda para estudiantes');

INSERT INTO intenciones (id, nombre, descripcion) VALUES
  ('1ccc1ec3-7fdb-4f2c-8423-2346b6a13850', 'Compra', 'Intención de comprar una propiedad'),
  ('cda6f3a7-2be9-4473-b7e6-aec31cfeecb5', 'Renta', 'Intención de rentar una propiedad');

INSERT INTO plazos (id, nombre, descripcion) VALUES
  ('5aa36812-5ea6-4ff6-abbf-a196721fa822', 'Inmediato', 'Lo antes posible'),
  ('68b5012d-a18e-4603-a2cb-cada51934ace', 'Corto plazo', 'En los próximos 3-6 meses'),
  ('c21be765-4bc3-4581-aace-ad6c4df87725', 'Mediano plazo', 'Dentro de 6-12 meses'),
  ('2275b6d9-24b4-43ef-99bf-0dbf0114b15c', 'Largo plazo', 'Más de 12 meses'),
  ('90b8765d-fa79-4d78-b9fe-b0ea69b45d6c', 'Flexible', 'Sin plazo definido');

INSERT INTO estilos_vida (id, nombre, descripcion) VALUES
  ('dd9942dd-9c89-4528-9089-cb86c726b6aa', 'Escolar', 'Cerca de escuelas y parques'),
  ('7f16c7cb-f985-4fcb-a8a9-5bb4355adfb0', 'Suburbano', 'Zona residencial tranquila'),
  ('4dab9614-2bda-49b9-b568-f4cc4476f0e1', 'Privado', 'Comunidad cerrada con amenidades'),
  ('3e43066e-890a-40b5-b13a-66c89e58d41f', 'Naturaleza', 'Cerca de áreas naturales'),
  ('e281511e-a388-495d-97c7-7e398058f417', 'Residencial', 'Para inversión residencial'),
  ('badb7d3c-5497-434f-aee8-93d1b40935a1', 'Comercial', 'Para inversión comercial'),
  ('4a2e2481-99df-4089-8e81-1e2844429545', 'Mixto', 'Para uso mixto');